from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.functions import monotonically_increasing_id

# Creating spark object

spark = SparkSession.builder.appName("DeltaTableJsonExample") \
    .config("spark.jars.packages", "io.delta:delta-core_2.12:2.1.0") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()


data = spark.read.option("header","true")\
    .csv("s3://iceberg-exploration/pravallika/source/custom.csv")
data.show()

# numFiles = 16
# .repartition(numFiles)
data.write.format("delta")\
    .mode("overwrite")\
    .option("overwriteSchema", "true") \
    .partitionBy("Year","month") \
    .option("overwriteSchema", "true")\
    .option("path","s3://iceberg-exploration/pravallika/Partition_Delta/")\
    .saveAsTable("deltatable")

#creating data frame to write data
tb_df = spark.table("deltatable")
spark.sql("describe table extended deltatable")

# spark.sql("ALTER TABLE deltatable SET TBLPROPERTIES ('delta.minReaderVersion' = '2','delta.minWriterVersion' = '5','delta.columnMapping.mode' = 'name'")