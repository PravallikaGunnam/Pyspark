from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
spark = (SparkSession.builder.appName("iceberg_file_streaming")\
         .config("spark.sql.catalog.dev1.warehouse", "s3://iceberg-exploration/pravallika/warehouse/")\
         .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
         .config("spark.sql.catalog.dev1", "org.apache.iceberg.spark.SparkCatalog") \
         .config("spark.sql.catalog.dev1.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")  \
         .config("spark.hadoop.hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").getOrCreate())


# df = spark.read.format("csv")\
#     .option("header","true")\
#     .load("s3://iceberg-exploration/pravallika/source/custom.csv")
# df.createOrReplaceTempView("temp")
# spark.sql("CREATE or REPLACE TABLE dev1.iceberg.timetravel USING iceberg AS SELECT * FROM temp ")

# df = spark.read.format("iceberg")\
#     .option("snapshot-id", 6510106489161421251)\
#     .load("dev1.iceberg.timetraveltable")
# df.show()
# print("sucess")

######## for expiring snapshots
tsToExpire =datetime.now()
# table = spark.read.format("iceberg").load("dev1.iceberg.timetravel")
# table.expire_snapshots().expireOlderThan(tsToExpire).commit()

# spark.sql("""ALTER TABLE dev1.iceberg.timetravel UNSET TBLPROPERTIES ('write.target-file-size-bytes')""").show(100)
# spark.sql("""CALL dev1.system.rewrite_data_files(table => 'dev1.iceberg.timetravel', options => map('target-file-size-bytes','536870912'))""").show()

spark.sql("""CALL dev1.system.expire_snapshots(table => 'dev1.iceberg.timetravel', older_than => timestamp '2023-02-23 06:59:35',retain_last => 1)""").show()