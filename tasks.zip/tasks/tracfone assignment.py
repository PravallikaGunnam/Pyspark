from pyspark.sql import SparkSession
import findspark
findspark.init()
spark=SparkSession.builder.getOrCreate()
df=spark.read.csv("Household_expenditure_details",header=True)
df.show()