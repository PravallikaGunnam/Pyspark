import numpy as np
##1 dimentional array
a=np.array([1,2,3,4,5,6,7])
# print(a)

## 2 dimentional arry(rows,columns)
# b=np.array([[1,2,3,4,5],[2,3,4,5,9]])
# print(b)

###Finding the dimention
# print(a.ndim)
# print(b.ndim)

###finding the shapes(rows,columns)
# print(a.shape)
# print(b.shape)

##data types(It will give the datatype)
# print(a.dtype)
# print(b.dtype)

##for finding the itemsize
# print(a.itemsize)
# print(b.itemsize)

## for finding the bytes(7*4=28)
# print(a.nbytes)
# print(b.nbytes)

b=np.array([[1,2,3,4,5],[2,3,4,5,9]])
# print(b)
#
# print(b[1,2]) #(r,c)
# # print(b[2,2])# error
# print(b[0,:]) # it will give all columns
# print(b[1,:]) # it will give all columns

##Three dimentional
c=np.array([[1,2,3,4],[3,4,2,4],[5,6,7,8],[3,4,5,6]])
# print(c)
# print(c.ndim)

## it will fill the 2 rows and 4 columns of zeros
# s=np.zeros((2,4))
# print(s)

# s=np.ones((2,3,4))
# print(s)

# it will fill 2 rows and 3 columns of 30's
d=np.full((2,3),30)
# print(d)

# it will take numbers randomly
r=np.random.rand(3,2)
print(r)

## Identity
i=np.identity(4)
print(i)