from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
spark=SparkSession.builder.getOrCreate()
df=spark.read.format("parquet")\
    .load("s3://iceberg-exploration/pravallika/athenatable3/data/70b37193/00000-0-6549e7ad-442b-4508-aa05-dabc93ef9b8d-00001.parquet")
df.printSchema()
df.show()
# df1=df.createOrReplaceTempView("nested")

# df_ddr=df.select(col("ddr.ddrheader").withField("audiofeatures",col("audiofeatures").cast("int")))
# df_ddr.printSchema()

############for adding column in the schema
# df_ddrheader=df.select("ddr.ddrheader")
# df1=df_ddrheader.withColumn("video",lit(10))
# df1.printSchema()

# df2=df.select(col("ddr.ddrheader").withField("video",lit(10)))
# df2.printSchema()
#
# ##remove column from struct
# df3=df2.dropField("video")
# df3.printSchema()