from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
spark = (SparkSession.builder.appName("iceberg_file_streaming")\
         .config("spark.sql.catalog.dev1.warehouse", "s3://iceberg-exploration/pravallika/warehouse/")\
         .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
         .config("spark.sql.catalog.dev1", "org.apache.iceberg.spark.SparkCatalog") \
         .config("spark.sql.catalog.dev1.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")  \
         .config("spark.hadoop.hive.metastore.client.factory.class", "com.amazonaws..glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").getOrCreate())

# df = spark.read.format("csv")\
#     .option("header","true")\
#     .load("s3://iceberg-exploration/pravallika/source/custom.csv")
# df2=df.withColumn("Q2",col("Q2").cast("int"))
# df2.createOrReplaceTempView("temp")
# spark.sql("CREATE or REPLACE TABLE dev1.iceberg.decending2 USING iceberg AS SELECT * FROM temp ")
# spark.sql("""ALTER TABLE dev1.iceberg.decending2 WRITE ORDERED BY Q2 DESC""" )
# df2.writeTo("dev1.iceberg.decending2").append()
# df2.show()
# print("sucess")


df = spark.read.format("iceberg")\
    .load("dev1.iceberg.decending2")
spark.sql("""ALTER TABLE dev1.iceberg.decending2 WRITE ORDERED BY Value DESC""" )
df.writeTo("dev1.iceberg.decending2").append()
print("sucess")

# spark.sql("""select * from dev1.iceberg.sortorder""")
# df.writeTo("dev1.iceberg.sortorder").append()
# print("sucess")
# spark.sql("""ALTER TABLE dev1.iceberg.sorting WRITE ORDERED BY salary""" )