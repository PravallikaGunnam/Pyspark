from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
spark = (SparkSession.builder.appName("iceberg_file_streaming")\
         .config("spark.sql.catalog.dev1.warehouse", "s3://iceberg-exploration/pravallika/warehouse/")\
         .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
         .config("spark.sql.catalog.dev1", "org.apache.iceberg.spark.SparkCatalog") \
         .config("spark.sql.catalog.dev1.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")  \
         .config("spark.hadoop.hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").getOrCreate())

schema=StructType([
    StructField("empid",IntegerType(),True),
    StructField("firstname",StringType(),True),
    StructField("dept",StringType(),True),
    StructField("salary",IntegerType(),True)
])

filestreaming=spark.readStream.format("csv") \
    .schema(schema)\
    .option("header",True)\
    .option("sep",",")\
    .option("recursiveFileLookup", "true")\
    .load(path="s3://iceberg-exploration/pravallika/filestream-inputs/")

filestream=filestreaming.writeStream.format("parquet")\
    .outputMode("append")\
    .option("path","s3://iceberg-exploration/pravallika/filestream-outputs/")\
    .option("checkPointLocation","s3://iceberg-exploration/pravallika/checkpoint/").start()
filestream.awaitTermination()


# filestreaming=spark.readStream.format("csv") \
#     .schema(schema)\
#     .option("header",True)\
#     .option("sep",",")\
#     .load(path="s3://iceberg-exploration/pravallika/source/")
# filestreaming.show()
#
# stream=filestreaming.writeStream \
#     .format("iceberg")\
#     .outputMode("append")\
#     .option("path","dev1.sample.department1")\
#     .option("checkpointLocation","s3://iceberg-exploration/pravallika/checkpoint/").start()
# stream.awaitTermination()
# stream.show()
# .option("checkPointLocation","s3://iceberg-exploration/pravallika/checkpoint/")
