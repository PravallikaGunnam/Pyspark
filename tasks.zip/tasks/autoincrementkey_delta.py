####### for creating autoincrement key
from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.functions import monotonically_increasing_id

# Creating spark object

spark = SparkSession.builder.appName("DeltaTableJsonExample") \
    .config("spark.jars.packages", "io.delta:delta-core_2.12:2.1.0") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

data = spark.read.option("header","true").csv("s3://iceberg-exploration/pravallika/source/custom.csv")

data.write.format("delta").mode("append").option("overwriteSchema", "true").option("path","s3://iceberg-exploration/pravallika/delta/").saveAsTable("deltatable")

#creating data frame to write data
tb_df = spark.table("deltatable")
#added new column with auto_increment(monotonically_increasing_id())
tb_df.withColumn("id",monotonically_increasing_id()).show(truncate=False)

