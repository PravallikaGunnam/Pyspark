from sparkocr import start
from pyspark import SparkConf

conf = SparkConf()\
.set("spark.sql.autoBroadcastJoinThreshold", "-1")\
.set("spark.network.timeout", "600s")\
.set("spark.executor.heartbeatInterval", "500s")\
.set("spark.executor.memory", "4g")\
.set("spark.driver.memory","4g")

spark = start(secret="4.1.0-52f8e0a3b8cf4b1b63c864d38b2851b1f5484f25", nlp_version="4.1.0", extra_conf=conf)
from pyspark.ml import PipelineModel

from sparkocr.transformers import *

imagePath = "C:\\Sample\\test_sample.pdf"

# Read PDF files as binary file
df = spark.read \
  .format("binaryFile") \
  .load(imagePath)

# Extract text from PDF text layout
pdfToText = PdfToText() \
  .setInputCol("content") \
  .setOutputCol("text") \
  .setSplitPage(false)

# In case of `text` column contains less then 10 characters,
# pipeline run PdfToImage as fallback method
pdfToImage = PdfToImage() \
  .setInputCol("content") \
  .setOutputCol("image") \
  .setFallBackCol("text") \
  .setMinSizeBeforeFallback(10)

# OCR
ocr = ImageToText() \
  .setInputCol("image") \
  .setOutputCol("text")

# Define pipeline
pipeline = PipelineModel(stages=[
  pdfToText,
  pdfToImage,
  ocr,
])

data = pipeline.transform(df)

data.show()
