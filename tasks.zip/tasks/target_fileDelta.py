from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.functions import monotonically_increasing_id

# Creating spark object

spark = SparkSession.builder.appName("DeltaTableJsonExample") \
    .config("spark.jars.packages", "io.delta:delta-core_2.12:2.1.0") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()
# .config("delta.targetFileSize","1073741824")\

# Create a DataFrame
data = spark.read.option("header","true")\
    .csv("s3://iceberg-exploration/pravallika/source/custom.csv")

# spark.sql("CREATE or REPLACE TABLE deltatable USING delta repartitioned by (5) AS SELECT * FROM tempview").show()
data.write.format("delta")\
    .mode("overwrite")\
    .option("overwriteSchema", "true")\
    .option("path","s3://iceberg-exploration/pravallika/Target_sizeDelta/")\
    .saveAsTable("deltatable")

tb = spark.table("deltatable")
tb.show(truncate=False)





# spark.sql("alter table deltatable optimize").show()
# spark.sql("ALTER TABLE deltaTable SET TBLPROPERTIES (delta.autoOptimize.optimizeWrite = true, delta.autoOptimize.autoCompact = false, delta.targetFileSize = '1073741824')")
# # spark.sql("alter table deltatable SET TBLPROPERTIES ('write.target-file-size-bytes'='524288000') ")
# spark.sql("set spark.databricks.delta.autoCompact.enabled = true ")

# .config("delta.autoOptimize.optimizeWrite",True)\
#     .config("delta.autoOptimize.autoCompact",False)\
#     .config("delta.tuneFileSizesForRewrites",True)\
#     .config("delta.targetFileSize","5242880")\