from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
spark = (SparkSession.builder.appName("iceberg_file_streaming")\
         .config("spark.sql.shuffle.partitions", "3")\
         .config("spark.sql.catalog.dev1.warehouse", "s3://iceberg-exploration/pravallika/warehouse/")\
         .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
         .config("spark.sql.catalog.dev1", "org.apache.iceberg.spark.SparkCatalog") \
         .config("spark.sql.catalog.dev1.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")  \
         .config("spark.hadoop.hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").getOrCreate())

# df = spark.read.format("csv")\
#     .option("header","true")\
#     .load("s3://iceberg-exploration/pravallika/source/custom.csv")
# spark.sql("""CREATE TABLE dev1.iceberg.timetravel3 (
# exp_imp STRING,
# Year STRING,
# month STRING,
# ym STRING,
# Country STRING,
# Custom STRING,
# hs2 STRING,
# hs4 STRING,
# hs6 STRING,
# hs9 STRING,
# Q1 STRING,
# Q2 STRING,
# Value STRING)
# USING ICEBERG
# TBLPROPERTIES ('format-version'='2',
#     'write.target-file-size-bytes'='536870912')
# """)
# df.writeTo("dev1.iceberg.timetravel3").append()
# df.show()
# print("sucess")

# spark.sql("""ALTER TABLE dev1.iceberg.timetravel3 UNSET TBLPROPERTIES ('write.target-file-size-bytes')""").show(100)
spark.sql("""CALL dev1.system.rewrite_data_files(table => 'dev1.iceberg.timetravel3', options => map('target-file-size-bytes','536870912','min-input-files','3'))""").show()


