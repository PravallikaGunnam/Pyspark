
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
# import findspark
# findspark.init()
spark=SparkSession.builder.getOrCreate()
# from pyspark.shell import spark
# df=spark.read.csv("DEPT.csv",header=True)
# df.show()
# df.printSchema()
#
# df.createTempView("Readcsv")
# spark.sql("select * from Readcsv").show()

# df.write.csv("write.csv")
# df.write.csv("sample.csv")


################ Reading particular file from directory
# file_stream_Df = spark.read.format("text")\
#     .option("header","true")\
#     .option("delimiter","\t")\
#     .option("inferschema","true")\
#     .load(r"C:\Users\Gunnam.Pravallika\Desktop\files\DataLake.txt")

# from pyspark import SparkContext
# sc=SparkContext()
# file_stream_Df = sc.wholeTextFiles(path="C:/Users/Gunnam.Pravallika/Desktop/files")
# # file_stream_Df.collect().foreach(println)
# # file_stream_Df.collect()


# # dirPath='C:/Users/Gunnam.Pravallika/Desktop/files\*'
# filesread=spark.read.json("C:/Users/Gunnam.Pravallika/Desktop/files\*")
# # filesread=spark.read.csv(dirPath)
# print(filesread.count())


filesread=spark.read.option("header","true").csv("s3://iceberg-exploration/pravallika/source/")
# filesread=spark.read.csv(dirPath)
# print(filesread.count())
filesread.printSchema()
filesread.show()
print(filesread.count())

# filesread=spark.read.csv("s3://iceberg-exploration/pravallika/scripts/DEPT.csv")
# # filesread=spark.read.csv(dirPath)
# # print(filesread.count())
# filesread.printSchema()


