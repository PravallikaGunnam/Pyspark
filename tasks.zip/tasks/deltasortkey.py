from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.functions import monotonically_increasing_id

# Creating spark object

spark = SparkSession.builder.appName("DeltaTableJsonExample") \
    .config("spark.jars.packages", "io.delta:delta-core_2.12:2.1.0") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()


# Create a DataFrame
data = spark.read.option("header","true").csv("s3://iceberg-exploration/pravallika/source/custom.csv")

data.write.format("delta").mode("append").option("overwriteSchema", "true").option("path","s3://iceberg-exploration/pravallika/delta/").saveAsTable("deltatable")

tb = spark.table("deltatable")
tb.show(truncate=False)

spark.sql("OPTIMIZE deltatable ZORDER BY (Country)").show(truncate=False)




# spark.sql("select Country, count(*) from deltatable group by Country=103")

# spark.sql("drop table if exists deltatable")
# print("Sucess")




