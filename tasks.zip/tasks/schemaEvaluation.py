from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
spark = (SparkSession.builder.appName("schema evaluation")\
         .config("spark.sql.catalog.dev1.warehouse", "s3://iceberg-exploration/pravallika/warehouse/")\
         .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
         .config("spark.sql.catalog.dev1", "org.apache.iceberg.spark.SparkCatalog") \
         .config("spark.sql.catalog.dev1.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")  \
         .config("spark.hadoop.hive.metastore.client.factory.class","com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").getOrCreate())

# schema=StructType([
#     StructField("empid",StringType(),True),
#     StructField("ename",StringType(),True),
#     # StructField("designation",StringType(),True),
# ])
#
# filestreaming=spark.readStream.format("parquet") \
#     .schema(schema)\
#     .option("sep",",") \
#     .load(path="s3://iceberg-exploration/pravallika/source/")
#
# stream=filestreaming.writeStream \
#     .format("iceberg") \
#     .outputMode("append")\
#     .option("path","dev1.sample.scenario4")\
#     .option("checkpointLocation","s3://iceberg-exploration/pravallika/checkpoint/").start()
# stream.awaitTermination()


# .option("mergeSchema","true")\
# .option("overwriteSchema", "true")\

filestreaming=spark.read.format("parquet") \
    .option("sep",",") \
    .option("mergeSchema","true")\
    .load(path="s3://iceberg-exploration/pravallika/source/")

stream=filestreaming.write \
    .format("parquet") \
    .mode("append")\
    .option("s3://iceberg-exploration/pravallika/filestream-outputs/")