from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
spark = (SparkSession.builder.appName("iceberg_file_streaming")\
         .config("spark.sql.catalog.dev1.warehouse", "s3://iceberg-exploration/pravallika/warehouse/")\
         .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
         .config("spark.sql.catalog.dev1", "org.apache.iceberg.spark.SparkCatalog") \
         .config("spark.sql.catalog.dev1.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")  \
         .config("spark.hadoop.hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").getOrCreate())
# spark=SparkSession.builder.appName("iceberg_file_streaming").getOrCreate()

# df = spark.read.format("csv").load("s3://iceberg-exploration/pravallika/source/DEPT.csv")
# spark.sql("""CREATE TABLE IF NOT EXISTS dev1.snapshot_maintenance.dept(
# empid int,
# firstname string,
# dept string,
# salary int)
# USING iceberg
# PARTITIONED By ("empid")
# TBLPROPERTIES ('write_target_data_file_size_bytes' = '134217728')""")
#
# df.writeTo("dev1.snapshot_maintenance.dept").append()


# df = spark.read.format("csv")\
#     .option("header","true")\
#     .load("s3://iceberg-exploration/pravallika/source/custom.csv")
# df.createOrReplaceTempView("tempview")
# spark.sql("CREATE or REPLACE TABLE dev1.iceberg.max USING iceberg partitioned by (Year)TBLPROPERTIES ('optimize_rewrite_max_data_file_size_bytes'='268435456') AS SELECT * FROM tempview").show()
# spark.sql("CREATE or REPLACE TABLE dev1.iceberg.samplefile USING iceberg partitioned by (Year) TBLPROPERTIES ('write.target-file-size-bytes'='268435456') AS SELECT * FROM tempview").show()


# df = spark.read.format("parquet")\
#     .load("s3://iceberg-exploration/pravallika/source/custom.csv")
# spark.sql("ALTER TABLE dev1.iceberg.sample7 UNSET TBLPROPERTIES ('write.target-file-size-bytes')")


spark.sql("CALL demo.system.rewrite_data_files(table => 'dev1.iceberg.sample7', options => map('target-file-size-bytes','268435456'))").show()