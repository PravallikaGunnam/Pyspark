from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
spark = (SparkSession.builder.appName("iceberg_file_streaming")\
         .config("spark.sql.catalog.dev1.warehouse", "s3://iceberg-exploration/pravallika/warehouse/")\
         .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
         .config("spark.sql.catalog.dev1", "org.apache.iceberg.spark.SparkCatalog") \
         .config("spark.sql.catalog.dev1.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")  \
         .config("spark.hadoop.hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").getOrCreate())

df=spark.read.format("parquet") \
    .option("header",True)\
    .option("sep",",")\
    .load(path="s3://iceberg-exploration/pravallika/nested-data/nested.parquet")
# df.createOrReplaceTempView("nested")
df.show()
nesteddf=df.writeTo("nestediceberg").using("iceberg").create()
nesteddf.show()