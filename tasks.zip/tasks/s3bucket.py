import boto3
s3 = boto3.resource('s3',
         aws_access_key_id=AKIA4TH7SFP76IEKKWNN,
         aws_secret_access_key= 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)
my_bucket = s3.Bucket('s3://iceberg-exploration/pravallika/scripts/24-csvfile.py')
for file in my_bucket.objects.all():
    print(file.key)